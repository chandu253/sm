insert into city (city_id,city_nm,created_by,created_dt,last_modified_by,last_modified_dt) values
(1, 'hyderabad', 'System', '2018-01-23', 'System', '2018-01-23'),
(2, 'pune', 'System', '2018-01-23', 'System', '2018-01-23'),
(3, 'munmbai', 'System', '2018-01-23', 'System', '2018-01-23'),
(4, 'bangalor', 'System', '2018-01-23', 'System', '2018-01-23'),
(5, 'delhi', 'System', '2018-01-23', 'System', '2018-01-23'),
(6, 'chennai', 'System', '2018-01-23', 'System', '2018-01-23');

