insert into role (role_id,role_code,role_display_nm,created_by,created_dt,
last_modified_by,last_modified_dt)values

(1, 'adm', 'administrator', 'SYSTEM', '2018-01-23', 'SYSTEM', '2018-01-23'),
(2,  'csr', 'customer_support_representative', 'SYSTEM', '2018-01-23 ', 'SYSTEM', '2018-01-23'),
(3,  'mer', 'member', 'SYSTEM', '2018-01-23', 'SYSTEM', '2018-01-23');
