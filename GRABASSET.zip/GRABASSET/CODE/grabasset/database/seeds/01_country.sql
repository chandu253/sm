insert into country (country_id,country_nm,created_by,created_dt,last_modified_by,last_modified_dt) values
(1, 'india', 'System', '2018-01-23', 'System', '2018-01-23');