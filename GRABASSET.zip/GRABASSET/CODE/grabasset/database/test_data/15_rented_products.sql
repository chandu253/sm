insert into rented_products (rent_id, product_id, product_rented_dt, product_returned_dt,product_condition, damage_charges_collected, created_by, created_dt, last_modified_by, last_modified_dt) values
(1,1,'2018-01-5','2018-01-15','good condition',0.00,'System', '2018-01-10', 'System','2018-01-23'),
(2,2,'2018-01-5','2018-01-15','ok',0.00,'System', '2018-01-10', 'System','2018-01-23'),
(3,3,'2018-01-6','2018-01-16','no issue',0.0,'System', '2018-01-10', 'System','2018-01-23'),
(4,4,'2018-01-10','2018-01-23','battery problem required maintainance',200.00,'System', '2018-01-10', 'System','2018-01-23'),
(5,5,'2018-01-10','2018-01-23','no issue',500.00,'System', '2018-01-10', 'System','2018-01-23'),
(6,6,'2018-01-10','2018-01-23','cracking sound  issue required maintainance',200.00,'System', '2018-01-10', 'System','2018-01-23'),
(7,7,'2018-01-11','2018-01-24','no issue',0.0,'System', '2018-01-10', 'System','2018-01-23');
