use grabassetdb;


insert into member_feedback (feedback_id, user_id, rating, comments,status, created_by,created_dt, last_modified_by, last_modified_dt) values
(1, 3, 5,'excellent','A','system',' 2018-01-24 12:19:03 ', ' system ', ' 2018-01-24 15:44:40 '),
(2, 4, 5,'excellent','A',' system ',' 2018-01-24 12:19:03 ', 'system', ' 2018-01-24 15:45:40 '),
(3, 5, 4,'good','A',' system ',' 2018-01-24 12:19:03 ', 'system', ' 2018-01-24 15:45:44 '),
(4, 6, 5,'excellent','A',' system ',' 2018-01-24 12:19:03 ', 'system', ' 2018-01-24 15:46:22 '),
(5, 7, 4,'good','A',' system ',' 2018-01-24 12:19:03 ', 'system', ' 2018-01-24 15:44:55');
