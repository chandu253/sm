use grabassetdb;


insert into order_product (order_id,user_id,product_id,rental_package_id,created_dt,created_by,last_modified_dt,last_modified_by) values
(1,3,1,1,'2018-01-23', 'System', '2018-01-23','System'),
(2,4,2,2,'2018-01-23', 'System', '2018-01-23','System'),
(3,5,3,3,'2018-01-23', 'System', '2018-01-23','System'),
(4,6,4,4,'2018-01-23', 'System', '2018-01-23','System'),
(5,7,5,5,'2018-01-23', 'System', '2018-01-23','System'),
(6,3,1,2,'2018-01-23', 'System', '2018-01-23','System');
