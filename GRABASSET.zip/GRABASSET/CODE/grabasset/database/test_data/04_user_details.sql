use grabassetdb;
insert into user_details(system_user_id,identification_no,identification_type,user_address_id,created_by,created_dt,last_modified_by,last_modified_dt)values
('1', '258045678945612', 'aadhar no', '1', 'system', '2017-11-12', 'system', '2017-11-12'),
('2', '894525825804567', 'aadhar no', '2', 'system', '2017-11-13', 'system', '2017-11-13'),
('3', '586782580459452', 'aadhar no', '3', 'system', '2017-11-14', 'system', '2017-11-14'),
('4', '825804594525867', 'aadhar no', '4', 'system', '2017-11-16', 'system', '2017-11-16'),
('5', '678258045525894', 'aadhar no', '5', 'system', '2017-11-19', 'system', '2017-11-19'),
('6', '948258045945258', 'aadhar no', '6', 'system', '2017-11-20', 'system', '2017-11-20'),
('7', '825804594525867', 'aadhar no', '7', 'system', '2017-11-21', 'system', '2017-11-21'),
('8', '586782045945258', 'aadhar no', '8', 'system', '2017-11-23', 'system', '2017-11-23');