use grabassetdb;


insert into product_maintainance 
(product_maintainance_id,product_id,repair_description,maintainance_charges,vendor_nm,comments,status,created_by,created_dt,last_modified_by,last_modified_dt) values
(1,1,'description1',780.00,'skshop','product is now good condition','OK', 'System', '2018-01-23', 'System', '2018-01-23'),
(2,4,'description4',1800.00,'tsrepair','product is now good condition','OP', 'System', '2018-01-23', 'System', '2018-01-23'),
(3,9,'description9',1780.00,'bnshop','product is now good condition','ok', 'System', '2018-01-23', 'System', '2018-01-23'),
(4,3,'description3',5280.00,'nmshop','product is now good condition','NR', 'System', '2018-01-23', 'System', '2018-01-23'),
(5,8,'description8',7520.00,'srshop','product is now good condition','ok', 'System', '2018-01-23', 'System', '2018-01-23');
