use grabassetdb;
insert into address(address_id,address_line1,address_line2,city,state,zip,country,created_by,created_dt,last_modified_by,last_modified_dt)values
(1,'101','2nd floor','hyderabad','TS','50038','india','System', '2018-01-23', 'System', '2018-01-23'),
(2,'102','2nd floor','hyderabad','TS','60038','india','System', '2018-01-23', 'System', '2018-01-23'),
(3,'103','2nd floor','hyderabad','TS','70038','india','System', '2018-01-23', 'System', '2018-01-23'),
(4,'104','2nd floor','hyderabad','TS','80038','india','System', '2018-01-23', 'System', '2018-01-23'),
(5,'105','2nd floor','hyderabad','TS','90038','india','System', '2018-01-23', 'System', '2018-01-23'),
(6,'106','2nd floor','hyderabad','TS','40038','india','System', '2018-01-23', 'System', '2018-01-23'),
(7,'107','2nd floor','hyderabad','TS','30038','india','System', '2018-01-23', 'System', '2018-01-23'),
(8,'108','2nd floor','hyderabad','TS','20038','india','System', '2018-01-23', 'System', '2018-01-23'),
(9,'109','2nd floor','hyderabad','TS','10038','india','System', '2018-01-23', 'System', '2018-01-23'),
(10,'110','2nd floor','pune','maharastra','50038','india','System', '2018-01-23', 'System', '2018-01-23'),
(11,'111','2nd floor','pune','maharastra','60038','india','System', '2018-01-23', 'System', '2018-01-23'),
(12,'112','2nd floor','pune','maharastra','70038','india','System', '2018-01-23', 'System', '2018-01-23'),
(13,'113','2nd floor','pune','maharastra','80038','india','System', '2018-01-23', 'System', '2018-01-23'),
(14,'114','2nd floor','pune','maharastra','90038','india','System', '2018-01-23', 'System', '2018-01-23'),
(15,'115','2nd floor','pune','maharastra','20038','india','System', '2018-01-23', 'System', '2018-01-23'),
(16,'116','2nd floor','pune','maharastra','40038','india','System', '2018-01-23', 'System', '2018-01-23'),
(17,'117','2nd floor','bangalor','karnatak','50038','india','System', '2018-01-23', 'System', '2018-01-23'),
(18,'118','2nd floor','bangalor','karnatak','30038','india','System', '2018-01-23', 'System', '2018-01-23'),
(19,'119','2nd floor','bangalor','karnatak','60038','india','System', '2018-01-23', 'System', '2018-01-23'),
(20,'120','2nd floor','bangalor','karnatak','90038','india','System', '2018-01-23', 'System', '2018-01-23');

