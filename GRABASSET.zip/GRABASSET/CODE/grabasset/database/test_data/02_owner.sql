use grabassetdb;
insert into owner(owner_id,first_nm,last_nm,contact_no,email_address,owner_address_id,created_by,created_dt,last_modified_by,last_modified_dt)values
(1,'Susanth','F','8974878968','susanth@gmail.com',4,'John','2017-11-12','John','2017-11-19'),
(2,'Suman','K','8787886755','suman@gmail.com',2,'John','2017-11-17','John','2017-11-17'),
(3,'Harika','C','8732685657','harika@gmail.com',1,'John','2017-11-25','John','2017-11-30'),
(4,'Akshay','G','9463786543','akshay@gmail.com',5,'David','2017-11-24','John','2018-01-06'),
(5,'Pawan','J','8376787564','pawan@gmail.com',3,'David','2017-12-13','John','2018-01-13');

