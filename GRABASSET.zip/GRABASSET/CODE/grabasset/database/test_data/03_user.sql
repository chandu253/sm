use grabassetdb;
insert into user(system_user_id,first_nm,last_nm,mobile_nbr,user_nm,password,role_id,activation_code,status,registerd_dt,activation_dt,created_by,created_dt,last_modified_by,last_modified_dt)values
(1,'John','K','9875674567','john@gmail.com','john',1,'ku87','A','2017-11-11','2017-11-11','Rod','2017-11-12','Rod','2017-11-14'),
(2,'David','G','9875687877','david@gmail.com','david',2,'eds8','A','2017-11-12','2017-11-12','John','2017-11-12','Rod','2017-11-15'),
(3,'Lakshman','S','8787788876','lakshman@gmail.com','lakshman',3,'ie78','A','2018-01-21','2018-01-22','David','2017-11-12','John','2018-01-14'),
(4,'Ajay','K','8767676587','ajay@gmail.com','ajay',3,'76gd','L','2017-12-22','2017-12-23','David','2017-11-12','David','2017-12-27'),
(5,'Karthik','H','7887676767','karthik@gmail.com','karthik',3,'7hj7','A','2018-01-21','2018-01-22','David','2017-11-12','David','2018-01-28'),
(6,'Simha','N','8797889798','simha@gmail.com','simha',3,'jdu8','D','2017-11-23','2017-11-24','David','2017-11-12','David','2017-11-27'),
(7,'Anand','L','9784677656','anand@gmail.com','anand',3,'kj88','R','2018-01-25',null,'David','2017-11-12','John',null),
(8,'Mahesh','G','8978897868','mahesh@gmail.com','mahesh',3,'7e8y','R','2018-01-25',null,'David','2017-11-12','John',null);
