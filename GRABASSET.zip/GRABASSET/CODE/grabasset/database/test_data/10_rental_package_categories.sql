use grabassetdb;

insert into rental_package_categories(rental_package_id,category_id,
late_fee_charges_per_hour,created_by,created_dt,last_modified_by,last_modified_dt) VALUES
(1,2,50.00,'system','2018-01-24 11:32:25','system','2018-01-24 16:31:53'),
(2,2,20.00,'system','2018-01-24 16:32:25','system','2018-01-24 16:31:53'),
(3,3,40.00,'system','2018-01-24 16:32:25','system','2018-01-24 16:31:53'),
(4,4,30.00,'system','2018-01-24 16:32:25','system','2018-01-24 16:31:53'),
(5,5,10.00,'system','2018-01-24 16:32:25','system','2018-01-24 16:31:53');
