package com.grabasset.user.initializer;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class GrabassetSecurityInitializer extends AbstractSecurityWebApplicationInitializer {

}