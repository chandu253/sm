package com.grabasset.user.login.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class GrabAssetUserLogoutController {
	@RequestMapping("/logout.htm")
	public String showUserLoginForm(){
		return "logout";
	}

}
