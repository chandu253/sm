package com.grabasset.user.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MemberDashBoardController {

	@RequestMapping("member-dashboard.htm")
	public String showMemberDashBoard(Model model) {

		return "member-dashboard";
	}
}
