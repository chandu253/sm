package com.grabasset.user.login.provider;


import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import com.grabasset.user.login.authentication.GrabAssetWebAuthenticationDetails;
import com.grabasset.user.login.service.UserDetailsServiceImpl;

@Component
public class AuthenticationProviderImpl extends DaoAuthenticationProvider {


	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {

		String userName = null;
		String source=null;
		UsernamePasswordAuthenticationToken token = (UsernamePasswordAuthenticationToken) authentication;
		GrabAssetWebAuthenticationDetails details=(GrabAssetWebAuthenticationDetails) authentication.getDetails();
		
		source=details.getSource();
		userName=token.getName();
		System.out.println(source+"  ---  "+userName);
		((UserDetailsServiceImpl)super.getUserDetailsService()).setSource(source);;
		
		super.getUserDetailsService().loadUserByUsername(userName);
		
		return super.authenticate(authentication);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}

}
