package com.grabasset.util;

public interface GrabAssetMail {

	String INFO = "grabasset@info.org";

	String CUSTOMER_REGISTRATION_TEMPLATE = "customer-registration";
}
