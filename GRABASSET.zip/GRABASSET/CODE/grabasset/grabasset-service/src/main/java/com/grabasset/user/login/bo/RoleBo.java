package com.grabasset.user.login.bo;

import java.io.Serializable;

public class RoleBo implements Serializable{
	private static final long serialVersionUID = 1L;

	protected int roleId;
	protected String roleCode;
	protected String roleName;

	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}

	public void setRoleCode(String roleCode) {
		this.roleCode = roleCode;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public int getRoleId() {
		return roleId;
	}

	public String getRoleCode() {
		return roleCode;
	}

	public String getRoleName() {
		return roleName;
	}

	@Override
	public String toString() {
		return "RoleBo [roleId=" + roleId + ", roleCode=" + roleCode + ", roleName=" + roleName + "]";
	}

}
