package com.grabasset.user.login.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.grabasset.user.dao.UserDao;
import com.grabasset.user.login.bo.UserLoginDetailsBo;
import com.grabasset.user.login.dto.UserDetailsImpl;

@Component
public class UserDetailsServiceImpl implements UserDetailsService {
	private String source;
	
	@Autowired
	private UserDao userDao;

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		UserLoginDetailsBo userLoginDetailsBo = null;

		userLoginDetailsBo = userDao.findAuthenticatedUser(userName,source);
		System.out.println(userLoginDetailsBo);
		UserDetails userDetails = new UserDetailsImpl(userLoginDetailsBo.getUserLoginBo().getUserName(), userLoginDetailsBo.getUserLoginBo().getPassword(), userLoginDetailsBo.getUserLoginBo().getStatus(),
				userLoginDetailsBo.getUserRoleBo().getRoleCode());

		return userDetails;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	
}
