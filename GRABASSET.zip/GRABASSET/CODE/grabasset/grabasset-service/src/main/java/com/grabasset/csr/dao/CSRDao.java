package com.grabasset.csr.dao;

import com.grabasset.csr.bo.AddressBo;
import com.grabasset.csr.bo.CSRDetailsBo;

public interface CSRDao {
	public boolean saveCSR(CSRDetailsBo csrDao);

	
}
