package com.grabasset.user.dao;

import java.util.List;

import com.grabasset.csr.bo.AddressBo;
import com.grabasset.csr.bo.UserDetailsBo;
import com.grabasset.user.bo.CityBo;
import com.grabasset.user.bo.CountryBo;
import com.grabasset.user.bo.StateBo;
import com.grabasset.user.bo.UserBo;
import com.grabasset.user.login.bo.UserLoginDetailsBo;

public interface UserDao {

	int saveUser(UserBo userBo);

	boolean isUserNameExists(String userName);

	UserBo getUser(int userId);

	boolean updateUserStatus(UserBo userBo);

	int getRole(String roleCode);

	int saveAddress(AddressBo addressBo);

	void saveUserDetails(UserDetailsBo userDetailsBo);

	List<CityBo> getCities();

	List<StateBo> getStates();

	List<CountryBo> getCountries();
	
	UserLoginDetailsBo findAuthenticatedUser(String userName,String source);

}
