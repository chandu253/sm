package com.grabasset.user.login.bo;

import java.io.Serializable;

public class UserLoginBo implements Serializable{
	private static final long serialVersionUID = 1L;

	protected String userName;
	protected String password;
	protected String status;

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String getUserName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

	public String getStatus() {
		return status;
	}

	@Override
	public String toString() {
		return "UserLoginBo [userName=" + userName + ", password=" + password + ", status=" + status + "]";
	}


}
