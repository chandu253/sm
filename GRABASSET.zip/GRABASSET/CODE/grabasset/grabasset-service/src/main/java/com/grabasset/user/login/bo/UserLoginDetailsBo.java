package com.grabasset.user.login.bo;

import java.io.Serializable;

public class UserLoginDetailsBo implements Serializable {
	@Override
	public String toString() {
		return "UserLoginDetailsBo [userLoginBo=" + userLoginBo + ", userRoleBo=" + userRoleBo + "]";
	}

	private static final long serialVersionUID = 1L;

	protected UserLoginBo userLoginBo;
	protected RoleBo userRoleBo;

	public UserLoginBo getUserLoginBo() {
		return userLoginBo;
	}

	public void setUserLoginBo(UserLoginBo userLoginBo) {
		this.userLoginBo = userLoginBo;
	}

	public RoleBo getUserRoleBo() {
		return userRoleBo;
	}

	public void setUserRoleBo(RoleBo userRoleBo) {
		this.userRoleBo = userRoleBo;
	}

}
